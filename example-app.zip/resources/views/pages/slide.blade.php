<h3 style="text-align: center; color:blueviolet">Sách hay nên đọc</h3>
        <div class="owl-carousel owl-theme">
            <div class="item">
                <img src="{{ asset('public/uploads/truyen/2b53fb5117a9ea9b770130ff07fe4.jpg') }}" alt="">
                <h5 style="text-align: center">Nghìn Obama</h5>
                <p style="text-align: center"><i class="fa-sharp fa-solid fa-eye"></i> 123000 </p>
                <center><a class="btn btn-danger btn-sm" href="">Đọc ngay</a></center>
            </div>
            <div class="item">
                <img src="{{ asset('public/uploads/truyen/2b53fb5117a9ea9b770130ff07fe4.jpg') }}" alt="">
                <h5 style="text-align: center">Nghìn Obama</h5>
                <p style="text-align: center"><i class="fa-sharp fa-solid fa-eye"></i> 123000 </p>
                <center><a class="btn btn-danger btn-sm" href="">Đọc ngay</a></center>
            </div>
            <div class="item">
                <img src="{{ asset('public/uploads/truyen/2b53fb5117a9ea9b770130ff07fe4.jpg') }}" alt="">
                <h5 style="text-align: center">Nghìn Obama</h5>
                <p style="text-align: center"><i class="fa-sharp fa-solid fa-eye"></i> 123000 </p>
                <center><a class="btn btn-danger btn-sm" href="">Đọc ngay</a></center>
            </div>
            <div class="item">
                <img src="{{ asset('public/uploads/truyen/2b53fb5117a9ea9b770130ff07fe4.jpg') }}" alt="">
                <h5 style="text-align: center">Nghìn Obama</h5>
                <p style="text-align: center"><i class="fa-sharp fa-solid fa-eye"></i> 123000 </p>
                <center><a class="btn btn-danger btn-sm" href="">Đọc ngay</a></center>
            </div>
            <div class="item">
                <img src="{{ asset('public/uploads/truyen/2b53fb5117a9ea9b770130ff07fe4.jpg') }}" alt="">
                <h5 style="text-align: center">Nghìn Obama</h5>
                <p style="text-align: center"><i class="fa-sharp fa-solid fa-eye"></i> 123000 </p>
                <center><a class="btn btn-danger btn-sm" href="">Đọc ngay</a></center>
            </div>
            <div class="item">
                <img src="{{ asset('public/uploads/truyen/2b53fb5117a9ea9b770130ff07fe4.jpg') }}" alt="">
                <h5 style="text-align: center">Nghìn Obama</h5>
                <p style="text-align: center"><i class="fa-sharp fa-solid fa-eye"></i> 123000 </p>
            </div>
            <div class="item">
                <img src="{{ asset('public/uploads/truyen/2b53fb5117a9ea9b770130ff07fe4.jpg') }}" alt="">
                <h5 style="text-align: center">Nghìn Obama</h5>
                <p style="text-align: center"><i class="fa-sharp fa-solid fa-eye"></i> 123000 </p>
            </div>
            <div class="item">
                <img src="{{ asset('public/uploads/truyen/2b53fb5117a9ea9b770130ff07fe4.jpg') }}" alt="">
                <h5 style="text-align: center">Nghìn Obama</h5>
                <p style="text-align: center"><i class="fa-sharp fa-solid fa-eye"></i> 123000 </p>
            </div>
        </div>
